import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, TrendingUp, Calendar, DollarSign, ArrowUpRight, ArrowDownRight } from 'lucide-react';
import { Button } from '@/components/ui/button';

type Period = 'day' | 'week' | 'month';

const Earnings = () => {
  const navigate = useNavigate();
  const [period, setPeriod] = useState<Period>('week');

  const earnings = {
    day: { total: 245.50, rides: 8, tips: 35.00 },
    week: { total: 1420.00, rides: 42, tips: 180.00 },
    month: { total: 5680.00, rides: 168, tips: 720.00 },
  };

  const currentEarnings = earnings[period];
  const previousEarnings = period === 'day' ? 198.00 : period === 'week' ? 1250.00 : 5200.00;
  const growth = ((currentEarnings.total - previousEarnings) / previousEarnings) * 100;
  const isPositive = growth >= 0;

  const transactions = [
    { id: 1, type: 'ride', description: 'Corrida - Marina → Gigoia', amount: 15.00, time: '14:32' },
    { id: 2, type: 'tip', description: 'Gorjeta recebida', amount: 5.00, time: '14:35' },
    { id: 3, type: 'ride', description: 'Corrida - Gigoia → Barra', amount: 25.00, time: '13:15' },
    { id: 4, type: 'ride', description: 'Corrida - Freitas → Marina', amount: 12.00, time: '12:00' },
    { id: 5, type: 'tip', description: 'Gorjeta recebida', amount: 10.00, time: '12:05' },
  ];

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-primary text-primary-foreground px-4 py-4 safe-area-top">
        <div className="flex items-center gap-4 mb-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)} className="text-primary-foreground hover:bg-primary-foreground/10">
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-xl font-bold">Ganhos</h1>
        </div>

        {/* Period Selector */}
        <div className="flex gap-2 mb-4">
          {(['day', 'week', 'month'] as Period[]).map((p) => (
            <button
              key={p}
              onClick={() => setPeriod(p)}
              className={`flex-1 py-2 px-4 rounded-lg text-sm font-medium transition-colors ${
                period === p
                  ? 'bg-primary-foreground text-primary'
                  : 'bg-primary-foreground/10 text-primary-foreground'
              }`}
            >
              {p === 'day' ? 'Hoje' : p === 'week' ? 'Semana' : 'Mês'}
            </button>
          ))}
        </div>

        {/* Total Earnings */}
        <div className="bg-primary-foreground/10 rounded-xl p-4">
          <div className="flex items-center justify-between mb-2">
            <p className="text-sm opacity-80">Total de ganhos</p>
            <div className={`flex items-center gap-1 text-sm ${isPositive ? 'text-success' : 'text-destructive'}`}>
              {isPositive ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
              <span>{Math.abs(growth).toFixed(1)}%</span>
            </div>
          </div>
          <p className="text-3xl font-bold">R$ {currentEarnings.total.toFixed(2).replace('.', ',')}</p>
        </div>
      </header>

      <div className="p-4 space-y-6">
        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-card rounded-xl p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <Calendar className="w-4 h-4 text-primary" />
              <p className="text-sm text-muted">Corridas</p>
            </div>
            <p className="text-2xl font-bold text-foreground">{currentEarnings.rides}</p>
          </div>
          <div className="bg-card rounded-xl p-4 border border-border">
            <div className="flex items-center gap-2 mb-2">
              <DollarSign className="w-4 h-4 text-success" />
              <p className="text-sm text-muted">Gorjetas</p>
            </div>
            <p className="text-2xl font-bold text-success">R$ {currentEarnings.tips.toFixed(2).replace('.', ',')}</p>
          </div>
        </div>

        {/* Transactions */}
        <div>
          <h2 className="text-lg font-semibold text-foreground mb-4">Histórico recente</h2>
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div
                key={tx.id}
                className="bg-card rounded-xl p-4 flex items-center justify-between border border-border"
              >
                <div className="flex items-center gap-3">
                  <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${
                    tx.type === 'tip' ? 'bg-success/10' : 'bg-primary/10'
                  }`}>
                    {tx.type === 'tip' ? (
                      <DollarSign className="w-5 h-5 text-success" />
                    ) : (
                      <TrendingUp className="w-5 h-5 text-primary" />
                    )}
                  </div>
                  <div>
                    <p className="font-medium text-foreground">{tx.description}</p>
                    <p className="text-sm text-muted">{tx.time}</p>
                  </div>
                </div>
                <p className={`font-bold ${tx.type === 'tip' ? 'text-success' : 'text-foreground'}`}>
                  +R$ {tx.amount.toFixed(2).replace('.', ',')}
                </p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Earnings;
