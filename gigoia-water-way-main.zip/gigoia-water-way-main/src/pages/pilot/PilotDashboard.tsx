import { useState, useEffect, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, Star, Ship, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GoogleMapView from '@/components/GoogleMapView';
import RideRequestCard from '@/components/RideRequestCard';
import ActiveRideCard from '@/components/ActiveRideCard';
import NotificationPermissionBanner from '@/components/NotificationPermissionBanner';
import PilotDrawer from '@/components/layout/PilotDrawer';
import ProfileIncompleteModal from '@/components/ProfileIncompleteModal';
import { useApp } from '@/contexts/AppContext';
import { useNotifications } from '@/hooks/useNotifications';
import { useNotificationSound } from '@/hooks/useNotificationSound';
import { usePilotStats } from '@/hooks/usePilotStats';
import { supabase } from '@/integrations/supabase/client';
import { DbRide, Ride } from '@/types';
import { toast } from 'sonner';
import { useAuthContext } from '@/contexts/AuthContext';
import { validatePilotProfile } from '@/utils/profileValidation';
import { safeDbOperation, getFriendlyErrorMessage } from '@/utils/retryOperation';

const PilotDashboard = () => {
  const navigate = useNavigate();
  const { isPilotOnline, setIsPilotOnline } = useApp();
  const { pilotProfile } = useAuthContext();
  const [rides, setRides] = useState<Ride[]>([]);
  const [activeRide, setActiveRide] = useState<DbRide | null>(null);
  const [showNotificationBanner, setShowNotificationBanner] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [acceptingRideId, setAcceptingRideId] = useState<string | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [missingFields, setMissingFields] = useState<string[]>([]);
  const { permission, requestPermission, notifyNewRideRequest } = useNotifications();
  const { playNewRideSound } = useNotificationSound();
  const { stats, loading: statsLoading, pilotId } = usePilotStats();

  // Convert database ride to app ride format
  const dbRideToRide = useCallback((dbRide: DbRide): Ride => ({
    id: dbRide.id,
    passengerId: dbRide.passenger_device_id,
    passengerName: dbRide.passenger_name || 'Passageiro',
    passengerPhoto: '/placeholder.svg',
    pilotId: dbRide.pilot_id || undefined,
    origin: {
      id: 'origin',
      name: dbRide.origin_name,
      address: dbRide.origin_address || '',
      coordinates: [dbRide.origin_lng, dbRide.origin_lat],
    },
    destination: {
      id: 'destination',
      name: dbRide.destination_name || 'Destino',
      address: dbRide.destination_address || '',
      coordinates: [dbRide.destination_lng || 0, dbRide.destination_lat || 0],
    },
    status: dbRide.status,
    price: dbRide.price,
    estimatedTime: dbRide.estimated_time || 0,
    distance: 0,
    createdAt: new Date(dbRide.created_at),
  }), []);

  // Fetch pending rides with retry
  const fetchPendingRides = useCallback(async () => {
    const { data: result, error } = await safeDbOperation(async () => {
      const { data, error } = await supabase
        .from('rides')
        .select('*')
        .eq('status', 'pending')
        .order('created_at', { ascending: false });

      if (error) throw error;
      return data;
    });

    if (error) {
      console.error('Error fetching rides:', error);
      return;
    }

    if (result) {
      setRides(result.map((r) => dbRideToRide(r as DbRide)));
    }
  }, [dbRideToRide]);

  // Check active ride for pilot
  useEffect(() => {
    if (!pilotId) return;

    const checkActiveRideForPilot = async () => {
      const { data: result } = await safeDbOperation(async () => {
        const { data, error } = await supabase
          .from('rides')
          .select('*')
          .eq('pilot_id', pilotId)
          .in('status', ['accepted', 'pilot_arriving', 'in_progress'])
          .order('created_at', { ascending: false })
          .limit(1)
          .maybeSingle();

        if (error) throw error;
        return data;
      });

      if (result) {
        setActiveRide(result as DbRide);
      } else {
        setActiveRide(null);
      }
    };

    checkActiveRideForPilot();
  }, [pilotId]);

  const handleRideCancelled = () => {
    setActiveRide(null);
  };

  // Subscribe to new rides when online
  useEffect(() => {
    if (!isPilotOnline) {
      setRides([]);
      return;
    }

    fetchPendingRides();

    const channel = supabase
      .channel('pilot-rides')
      .on(
        'postgres_changes',
        {
          event: 'INSERT',
          schema: 'public',
          table: 'rides',
          filter: 'status=eq.pending',
        },
        (payload) => {
          console.log('New ride request:', payload);
          const newRide = dbRideToRide(payload.new as DbRide);
          setRides((prev) => [newRide, ...prev]);
          
          playNewRideSound();
          notifyNewRideRequest(
            newRide.passengerName,
            newRide.origin.name,
            newRide.price
          );
        }
      )
      .on(
        'postgres_changes',
        {
          event: 'UPDATE',
          schema: 'public',
          table: 'rides',
        },
        (payload) => {
          const updatedRide = payload.new as DbRide;
          if (updatedRide.status !== 'pending') {
            setRides((prev) => prev.filter((r) => r.id !== updatedRide.id));
          }
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [isPilotOnline, fetchPendingRides, dbRideToRide, playNewRideSound, notifyNewRideRequest]);

  // Request notification permission when going online
  useEffect(() => {
    if (isPilotOnline && permission === 'default') {
      requestPermission();
    }
  }, [isPilotOnline, permission, requestPermission]);

  const drawerStats = {
    ridestoday: stats.ridesToday,
    earnings: stats.earnings,
    rating: stats.rating,
  };

  const handleAcceptRide = async (rideId: string) => {
    if (acceptingRideId || !pilotId) {
      if (!pilotId) {
        toast.error('Erro: ID do piloto não disponível');
      }
      return;
    }

    // Validate pilot profile before accepting
    const validation = validatePilotProfile(pilotProfile);
    if (!validation.isValid) {
      setMissingFields(validation.missingFields);
      setShowProfileModal(true);
      return;
    }

    setAcceptingRideId(rideId);
    
    try {
      const { data: result, error: opError } = await safeDbOperation(async () => {
        const { data, error } = await supabase
          .from('rides')
          .update({ 
            status: 'accepted',
            pilot_id: pilotId,
            pilot_name: pilotProfile?.full_name || 'Piloto',
            pilot_phone: pilotProfile?.phone || null,
            accepted_at: new Date().toISOString(),
          })
          .eq('id', rideId)
          .eq('status', 'pending')
          .select()
          .single();

        if (error) throw error;
        return data;
      }, { maxAttempts: 2 });

      if (opError) {
        if (opError.includes('não foi encontrado')) {
          toast.error('Corrida já foi aceita por outro piloto');
          setRides((prev) => prev.filter((r) => r.id !== rideId));
        } else {
          toast.error(opError);
        }
        return;
      }

      if (!result) {
        toast.error('Corrida já foi aceita por outro piloto');
        setRides((prev) => prev.filter((r) => r.id !== rideId));
        return;
      }

      toast.success('Corrida aceita com sucesso!');
      navigate(`/pilot/ride/${rideId}`);
    } catch (error) {
      console.error('Error accepting ride:', error);
      toast.error(getFriendlyErrorMessage(error));
    } finally {
      setAcceptingRideId(null);
    }
  };

  const handleRejectRide = (rideId: string) => {
    setRides((prev) => prev.filter((r) => r.id !== rideId));
    toast('Corrida recusada');
  };

  return (
    <div className="min-h-screen min-h-[100dvh] bg-background">
      {/* Drawer */}
      <PilotDrawer open={drawerOpen} onOpenChange={setDrawerOpen} stats={drawerStats} />

      {/* Header - Uber driver style */}
      <header className="bg-primary text-primary-foreground safe-area-top">
        <div className="flex items-center justify-between p-4">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setDrawerOpen(true)}
            className="text-primary-foreground hover:bg-primary-foreground/10"
          >
            <Menu className="w-5 h-5" />
          </Button>
          
          {/* Online toggle - prominent */}
          <button
            onClick={() => setIsPilotOnline(!isPilotOnline)}
            className={`flex items-center gap-2 px-4 py-2 rounded-full transition-colors ${
              isPilotOnline ? 'bg-success text-success-foreground' : 'bg-primary-foreground/20'
            }`}
          >
            <div className={`w-2 h-2 rounded-full ${isPilotOnline ? 'bg-success-foreground animate-pulse' : 'bg-primary-foreground/50'}`} />
            <span className="text-sm font-semibold">{isPilotOnline ? 'Online' : 'Offline'}</span>
          </button>
          
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate('/pilot/history')}
            className="text-primary-foreground hover:bg-primary-foreground/10"
          >
            <History className="w-5 h-5" />
          </Button>
        </div>

        {/* Stats row */}
        <div className="flex items-center justify-around pb-4 px-4">
          <div className="text-center">
            <p className="text-2xl font-bold">{statsLoading ? '-' : stats.ridesToday}</p>
            <p className="text-xs opacity-70">Corridas</p>
          </div>
          <div className="w-px h-8 bg-primary-foreground/20" />
          <div className="text-center">
            <p className="text-2xl font-bold">R${statsLoading ? '-' : stats.earnings.toFixed(0)}</p>
            <p className="text-xs opacity-70">Ganhos</p>
          </div>
          <div className="w-px h-8 bg-primary-foreground/20" />
          <div className="text-center flex items-center gap-1">
            <Star className="w-4 h-4 text-yellow-400 fill-yellow-400" />
            <p className="text-2xl font-bold">{statsLoading ? '-' : stats.rating}</p>
          </div>
        </div>
      </header>

      {/* Map section */}
      <div className="h-48 relative">
        <GoogleMapView showBoats={isPilotOnline} />
        {!isPilotOnline && (
          <div className="absolute inset-0 bg-background/90 flex flex-col items-center justify-center">
            <Ship className="w-12 h-12 text-muted mb-2" />
            <p className="text-sm font-medium text-muted">Fique online para receber corridas</p>
          </div>
        )}
      </div>

      {/* Ride requests */}
      <div className="p-4 pb-safe">
        {/* Card de corrida em andamento do piloto */}
        {activeRide && (
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-foreground mb-2">🚤 Sua corrida em andamento</h3>
            <ActiveRideCard
              ride={activeRide}
              userType="pilot"
              onCancelled={handleRideCancelled}
            />
          </div>
        )}

        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-foreground">
            {isPilotOnline ? 'Solicitações' : 'Você está offline'}
          </h2>
          {isPilotOnline && rides.length > 0 && (
            <span className="text-xs text-muted">{rides.length} disponíveis</span>
          )}
        </div>

        {isPilotOnline && rides.length > 0 ? (
          <div className="space-y-3">
            {rides.map((ride) => (
              <RideRequestCard
                key={ride.id}
                ride={ride}
                onAccept={() => handleAcceptRide(ride.id)}
                onReject={() => handleRejectRide(ride.id)}
                isAccepting={acceptingRideId === ride.id}
              />
            ))}
          </div>
        ) : isPilotOnline ? (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-muted/10 rounded-full flex items-center justify-center mx-auto mb-3">
              <Ship className="w-8 h-8 text-muted" />
            </div>
            <p className="text-muted font-medium">Aguardando novas solicitações...</p>
            <p className="text-xs text-muted/70 mt-1">Você receberá uma notificação</p>
          </div>
        ) : (
          <div className="text-center py-8">
            <p className="text-muted text-sm">Ative o modo online para começar a receber corridas</p>
          </div>
        )}
      </div>
      
      {/* Notification Banner */}
      {showNotificationBanner && isPilotOnline && (
        <NotificationPermissionBanner onClose={() => setShowNotificationBanner(false)} />
      )}

      {/* Profile Incomplete Modal */}
      <ProfileIncompleteModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onGoToProfile={() => {
          setShowProfileModal(false);
          navigate('/pilot/profile');
        }}
        missingFields={missingFields}
        userType="pilot"
      />
    </div>
  );
};

export default PilotDashboard;
