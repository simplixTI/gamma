import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Menu, Search, Clock, MapPin, History } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GoogleMapView from '@/components/GoogleMapView';
import BottomSheet from '@/components/BottomSheet';
import NotificationPermissionBanner from '@/components/NotificationPermissionBanner';
import PassengerDrawer from '@/components/layout/PassengerDrawer';
import RecentRidesCard from '@/components/RecentRidesCard';
import ActiveRideCard from '@/components/ActiveRideCard';
import { locations } from '@/data/mockData';
import { useApp } from '@/contexts/AppContext';
import { useAuthContext } from '@/contexts/AuthContext';
import { getCurrentRide } from '@/services/rideService';
import { Location, DbRide } from '@/types';

const PassengerHome = () => {
  const navigate = useNavigate();
  const { setOrigin, setDestination, setCurrentPilot, setRideStatus } = useApp();
  const { user } = useAuthContext();
  const [showNotificationBanner, setShowNotificationBanner] = useState(true);
  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeRide, setActiveRide] = useState<DbRide | null>(null);

  // Ao abrir o app, verificar se existe corrida em andamento para esse passageiro
  useEffect(() => {
    if (!user?.id) return;

    const checkOngoingRide = async () => {
      try {
        const ride = await getCurrentRide(user.id);
        if (!ride) {
          setActiveRide(null);
          setRideStatus('idle');
          return;
        }

        setActiveRide(ride as DbRide);

        // Montar origem/destino no contexto para telas seguintes
        const originLocation: Location = {
          id: 'origin',
          name: ride.origin_name,
          address: ride.origin_address || '',
          coordinates: [ride.origin_lng, ride.origin_lat],
        };
        const destinationLocation: Location = {
          id: 'destination',
          name: ride.destination_name || 'Destino',
          address: ride.destination_address || '',
          coordinates: [ride.destination_lng || 0, ride.destination_lat || 0],
        };
        setOrigin(originLocation);
        setDestination(destinationLocation);

        // Se já houver piloto associado, preencher card
        if (ride.pilot_id) {
          setCurrentPilot({
            id: ride.pilot_id,
            name: ride.pilot_name || 'Piloto',
            photo: '/placeholder.svg',
            rating: 4.9,
            boat: 'Lancha Rápida',
            phone: ride.pilot_phone || '',
          });
        }

        // Atualizar status no contexto
        if (ride.status === 'pending') {
          setRideStatus('searching');
        } else if (ride.status === 'accepted' || ride.status === 'pilot_arriving') {
          setRideStatus(ride.status === 'accepted' ? 'matched' : 'arriving');
        } else if (ride.status === 'in_progress') {
          setRideStatus('in_progress');
        } else {
          setRideStatus('idle');
        }
      } catch (error) {
        console.error('Erro ao buscar corrida em andamento:', error);
      }
    };

    // Busca inicial
    checkOngoingRide();

    // Polling a cada 5 segundos como fallback para realtime
    const interval = setInterval(() => {
      console.log('[PassengerHome] Polling current ride...');
      checkOngoingRide();
    }, 5000);

    return () => clearInterval(interval);
  }, [user?.id, setOrigin, setDestination, setCurrentPilot, setRideStatus]);

  const handleRideCancelled = () => {
    setActiveRide(null);
    setRideStatus('idle');
  };

  const handleLocationSelect = (location: typeof locations[0]) => {
    setOrigin(location);
    navigate('/passenger/request');
  };

  const handleSearchClick = () => {
    navigate('/passenger/request');
  };

  return (
    <div className="h-screen h-[100dvh] bg-background relative overflow-hidden">
      {/* Drawer */}
      <PassengerDrawer open={drawerOpen} onOpenChange={setDrawerOpen} />

      {/* Map */}
      <div className="absolute inset-0">
        <GoogleMapView 
          onLocationSelect={(location: Location) => handleLocationSelect(location)}
          showBoats={true}
        />
      </div>

      {/* Header - Uber style */}
      <header className="absolute top-0 left-0 right-0 z-30 p-4 safe-area-top">
        <div className="flex items-center gap-3">
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => setDrawerOpen(true)}
            className="shrink-0 w-10 h-10 bg-card shadow-md rounded-full"
          >
            <Menu className="w-5 h-5" />
          </Button>
          <div className="flex-1" />
          <Button 
            variant="ghost" 
            size="icon" 
            onClick={() => navigate('/passenger/history')}
            className="shrink-0 w-10 h-10 bg-card shadow-md rounded-full"
          >
            <History className="w-5 h-5" />
          </Button>
        </div>
      </header>

      {/* Notification Permission Banner */}
      {showNotificationBanner && (
        <div className="absolute bottom-0 left-0 right-0 z-40">
          <NotificationPermissionBanner onClose={() => setShowNotificationBanner(false)} />
        </div>
      )}

      {/* Bottom Sheet - Uber style */}
      <BottomSheet>
        {/* Card de corrida em andamento */}
        {activeRide && (
          <div className="mb-4">
            <h3 className="text-sm font-semibold text-foreground mb-2">🚤 Corrida em andamento</h3>
            <ActiveRideCard
              ride={activeRide}
              userType="passenger"
              onCancelled={handleRideCancelled}
            />
          </div>
        )}

        {/* Recent rides card - só mostra se não tiver corrida ativa */}
        {!activeRide && (
          <div className="mb-4">
            <RecentRidesCard />
          </div>
        )}

        {/* Search bar */}
        <button
          onClick={handleSearchClick}
          className="w-full flex items-center gap-3 bg-muted/10 rounded-lg px-4 py-3.5 text-left active:bg-muted/20 transition-colors mb-4"
        >
          <Search className="w-5 h-5 text-foreground" />
          <span className="text-foreground font-medium">Para onde?</span>
          <div className="ml-auto flex items-center gap-2 bg-card rounded-full px-3 py-1.5 shadow-sm">
            <Clock className="w-3.5 h-3.5 text-muted" />
            <span className="text-xs font-medium">Agora</span>
          </div>
        </button>

        {/* Quick access locations */}
        <div className="space-y-1">
          {locations.slice(0, 3).map((location, index) => (
            <button
              key={location.id}
              onClick={() => handleLocationSelect(location)}
              className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-muted/5 active:bg-muted/10 transition-colors"
            >
              <div className="w-10 h-10 bg-muted/10 rounded-full flex items-center justify-center">
                <MapPin className="w-5 h-5 text-muted" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-foreground text-sm">{location.name}</p>
                <p className="text-xs text-muted truncate">{location.address}</p>
              </div>
            </button>
          ))}
        </div>

        {/* Divider */}
        <div className="h-px bg-border my-3" />

        {/* All locations */}
        <h3 className="text-xs font-semibold text-muted uppercase tracking-wide mb-2">
          Todos os pontos
        </h3>
        <div className="space-y-1">
          {locations.map((location) => (
            <button
              key={location.id}
              onClick={() => handleLocationSelect(location)}
              className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-muted/5 active:bg-muted/10 transition-colors"
            >
              <div className="w-8 h-8 bg-muted/10 rounded-full flex items-center justify-center">
                <MapPin className="w-4 h-4 text-muted" />
              </div>
              <div className="flex-1 text-left">
                <p className="font-medium text-foreground text-sm">{location.name}</p>
                <p className="text-xs text-muted truncate">{location.address}</p>
              </div>
              <span className="text-xs text-muted">{location.estimatedTime}</span>
            </button>
          ))}
        </div>
      </BottomSheet>
    </div>
  );
};

export default PassengerHome;
