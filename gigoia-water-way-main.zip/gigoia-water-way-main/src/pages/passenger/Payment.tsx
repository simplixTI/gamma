import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, CreditCard, Plus, Trash2, Check } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { toast } from 'sonner';

interface PaymentMethod {
  id: string;
  type: 'credit' | 'debit' | 'pix';
  lastDigits?: string;
  brand?: string;
  isDefault: boolean;
}

const Payment = () => {
  const navigate = useNavigate();
  const [methods, setMethods] = useState<PaymentMethod[]>([
    { id: '1', type: 'credit', lastDigits: '1234', brand: 'Visa', isDefault: true },
    { id: '2', type: 'pix', isDefault: false },
  ]);

  const handleSetDefault = (id: string) => {
    setMethods(methods.map(m => ({
      ...m,
      isDefault: m.id === id,
    })));
    toast.success('Método de pagamento padrão atualizado');
  };

  const handleDelete = (id: string) => {
    setMethods(methods.filter(m => m.id !== id));
    toast.success('Método de pagamento removido');
  };

  const getMethodIcon = (type: string) => {
    switch (type) {
      case 'pix':
        return '💰';
      case 'credit':
      case 'debit':
        return '💳';
      default:
        return '💳';
    }
  };

  const getMethodLabel = (method: PaymentMethod) => {
    if (method.type === 'pix') return 'Pix';
    return `${method.brand} •••• ${method.lastDigits}`;
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-card border-b border-border px-4 py-4 safe-area-top">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => navigate(-1)}>
            <ArrowLeft className="w-6 h-6" />
          </Button>
          <h1 className="text-xl font-bold text-foreground">Pagamento</h1>
        </div>
      </header>

      <div className="p-4 space-y-4">
        {/* Payment Methods */}
        <div className="space-y-3">
          {methods.map((method) => (
            <div
              key={method.id}
              className="bg-card rounded-xl p-4 flex items-center gap-4 border border-border"
            >
              <div className="w-12 h-12 rounded-xl bg-muted/10 flex items-center justify-center text-2xl">
                {getMethodIcon(method.type)}
              </div>
              <div className="flex-1">
                <p className="font-medium text-foreground">{getMethodLabel(method)}</p>
                <p className="text-sm text-muted">
                  {method.type === 'pix' ? 'Pagamento instantâneo' : 'Cartão de crédito'}
                </p>
              </div>
              <div className="flex items-center gap-2">
                {method.isDefault ? (
                  <span className="text-xs bg-primary/10 text-primary px-2 py-1 rounded-full flex items-center gap-1">
                    <Check className="w-3 h-3" />
                    Padrão
                  </span>
                ) : (
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={() => handleSetDefault(method.id)}
                    className="text-xs"
                  >
                    Usar
                  </Button>
                )}
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => handleDelete(method.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="w-4 h-4" />
                </Button>
              </div>
            </div>
          ))}
        </div>

        {/* Add Method Button */}
        <Button
          variant="outline"
          fullWidth
          className="border-dashed"
          onClick={() => toast.info('Em breve: adicionar novo método de pagamento')}
        >
          <Plus className="w-5 h-5 mr-2" />
          Adicionar método de pagamento
        </Button>

        {/* Info */}
        <div className="bg-muted/5 rounded-xl p-4 mt-6">
          <div className="flex items-start gap-3">
            <CreditCard className="w-5 h-5 text-muted mt-0.5" />
            <div>
              <p className="text-sm font-medium text-foreground">Pagamento seguro</p>
              <p className="text-xs text-muted mt-1">
                Seus dados de pagamento são criptografados e protegidos. 
                Nunca armazenamos os números completos do cartão.
              </p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Payment;
