import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { ArrowLeft, Clock, Navigation, MapPin, Users } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GoogleMapView from '@/components/GoogleMapView';
import { locations } from '@/data/mockData';
import { useApp } from '@/contexts/AppContext';
import { useAuthContext } from '@/contexts/AuthContext';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';
import PaymentModal from '@/components/PaymentModal';
import ProfileIncompleteModal from '@/components/ProfileIncompleteModal';
import { validatePassengerProfile } from '@/utils/profileValidation';
import { safeDbOperation, getFriendlyErrorMessage } from '@/utils/retryOperation';

const RequestRide = () => {
  const navigate = useNavigate();
  const {
    origin,
    setOrigin,
    destination,
    setDestination,
    calculatePrice,
    calculateDistance,
    calculateTime,
  } = useApp();
  const { user, passengerProfile } = useAuthContext();

  const [showOriginPicker, setShowOriginPicker] = useState(!origin);
  const [showDestinationPicker, setShowDestinationPicker] = useState(false);
  const [passengerCount, setPassengerCount] = useState(1);
  const [isCreating, setIsCreating] = useState(false);
  const [showPaymentModal, setShowPaymentModal] = useState(false);
  const [currentRideId, setCurrentRideId] = useState<string | null>(null);
  const [showProfileModal, setShowProfileModal] = useState(false);
  const [missingFields, setMissingFields] = useState<string[]>([]);

  const canConfirm = origin && destination;
  const pricePerPerson = calculatePrice();
  const totalPrice = pricePerPerson * passengerCount;
  const distance = calculateDistance();
  const time = calculateTime();

  const handleConfirm = async () => {
    if (!origin || !destination || !user) {
      toast.error('Dados incompletos');
      return;
    }

    // Validate passenger profile
    const validation = validatePassengerProfile(passengerProfile);
    if (!validation.isValid) {
      setMissingFields(validation.missingFields);
      setShowProfileModal(true);
      return;
    }

    setIsCreating(true);
    try {
      const { data: result, error: opError } = await safeDbOperation(async () => {
        const { data: rideData, error: rideError } = await supabase
          .from('rides')
          .insert({
            origin_name: origin.name,
            origin_address: origin.address,
            origin_lat: origin.coordinates[1],
            origin_lng: origin.coordinates[0],
            destination_name: destination.name,
            destination_address: destination.address,
            destination_lat: destination.coordinates[1],
            destination_lng: destination.coordinates[0],
            price: totalPrice,
            estimated_time: time,
            passenger_device_id: user.id,
            passenger_user_id: user.id,
            passenger_name: passengerProfile?.full_name,
            passenger_phone: passengerProfile?.phone,
            status: 'pending',
            payment_status: 'pending',
          })
          .select()
          .single();

        if (rideError) throw rideError;
        return rideData;
      }, { maxAttempts: 3 });

      if (opError) {
        toast.error(opError);
        return;
      }

      if (result) {
        setCurrentRideId(result.id);
        setShowPaymentModal(true);
      }
    } catch (error) {
      console.error('Error creating ride:', error);
      toast.error(getFriendlyErrorMessage(error));
    } finally {
      setIsCreating(false);
    }
  };

  const handlePaymentComplete = async () => {
    if (!currentRideId) return;

    try {
      const { error } = await safeDbOperation(async () => {
        const { error: updateError } = await supabase
          .from('rides')
          .update({ payment_status: 'paid' })
          .eq('id', currentRideId);
        if (updateError) throw updateError;
      });

      if (error) {
        toast.error(error);
        return;
      }

      setShowPaymentModal(false);
      toast.success('Pagamento confirmado! Buscando piloto...');
      navigate('/passenger/searching');
    } catch (error) {
      console.error('Error updating payment status:', error);
      toast.error(getFriendlyErrorMessage(error));
    }
  };

  const handlePaymentCancel = async () => {
    if (currentRideId) {
      await supabase
        .from('rides')
        .update({ status: 'cancelled' })
        .eq('id', currentRideId);
    }
    setShowPaymentModal(false);
    setCurrentRideId(null);
  };

  return (
    <div className="h-screen h-[100dvh] bg-background relative overflow-hidden">
      {/* Map */}
      <div className="absolute inset-0">
        <GoogleMapView 
          showBoats={false} 
          selectedLocation={origin || destination}
          origin={origin}
          destination={destination}
        />
      </div>

      {/* Header */}
      <header className="absolute top-0 left-0 right-0 z-30 p-4 safe-area-top">
        <Button
          variant="ghost"
          size="icon"
          onClick={() => navigate('/passenger')}
          className="bg-card shadow-md rounded-full"
        >
          <ArrowLeft className="w-5 h-5" />
        </Button>
      </header>

      {/* Location inputs card */}
      <div className="absolute top-16 left-4 right-4 z-30 safe-area-top">
        <div className="bg-card rounded-xl shadow-lg p-4">
          {/* Origin */}
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-success shrink-0" />
            <button
              onClick={() => {
                setShowOriginPicker(true);
                setShowDestinationPicker(false);
              }}
              className="flex-1 text-left min-w-0 py-1"
            >
              {origin ? (
                <div>
                  <p className="font-medium text-foreground text-sm truncate">{origin.name}</p>
                </div>
              ) : (
                <p className="text-muted text-sm">Onde você está?</p>
              )}
            </button>
          </div>

          {/* Divider */}
          <div className="ml-1.5 my-2 flex items-center gap-2">
            <div className="w-px h-6 bg-border" />
          </div>

          {/* Destination */}
          <div className="flex items-center gap-3">
            <div className="w-3 h-3 rounded-full bg-foreground shrink-0" />
            <button
              onClick={() => {
                setShowDestinationPicker(true);
                setShowOriginPicker(false);
              }}
              className="flex-1 text-left min-w-0 py-1"
            >
              {destination ? (
                <div>
                  <p className="font-medium text-foreground text-sm truncate">{destination.name}</p>
                </div>
              ) : (
                <p className="text-muted text-sm">Para onde vai?</p>
              )}
            </button>
          </div>
        </div>

        {/* Location picker dropdown */}
        {(showOriginPicker || showDestinationPicker) && (
          <div className="mt-2 bg-card rounded-xl shadow-lg max-h-64 overflow-y-auto animate-scale-in">
            <div className="p-2">
              {locations
                .filter((loc) => showOriginPicker ? loc.id !== destination?.id : loc.id !== origin?.id)
                .map((location) => (
                  <button
                    key={location.id}
                    onClick={() => {
                      if (showOriginPicker) {
                        setOrigin(location);
                        setShowOriginPicker(false);
                        if (!destination) setShowDestinationPicker(true);
                      } else {
                        setDestination(location);
                        setShowDestinationPicker(false);
                      }
                    }}
                    className="w-full flex items-center gap-3 p-3 rounded-lg hover:bg-muted/5 active:bg-muted/10 transition-colors"
                  >
                    <div className="w-10 h-10 bg-muted/10 rounded-full flex items-center justify-center">
                      <MapPin className="w-5 h-5 text-muted" />
                    </div>
                    <div className="flex-1 text-left">
                      <p className="font-medium text-foreground text-sm">{location.name}</p>
                      <p className="text-xs text-muted">{location.address}</p>
                    </div>
                    <span className="text-xs text-muted">{location.estimatedTime}</span>
                  </button>
                ))}
            </div>
          </div>
        )}
      </div>

      {/* Bottom section - Trip confirmation */}
      {canConfirm && !showOriginPicker && !showDestinationPicker && (
        <div className="absolute bottom-0 left-0 right-0 z-30 bg-card rounded-t-3xl shadow-sheet animate-slide-up safe-area-bottom">
          {/* Handle */}
          <div className="flex justify-center py-3">
            <div className="w-10 h-1 bg-border rounded-full" />
          </div>

          <div className="px-4 pb-4">
            {/* Passenger count selector */}
            <div className="flex items-center justify-between p-3 bg-muted/5 rounded-xl mb-4">
              <div className="flex items-center gap-2">
                <Users className="w-5 h-5 text-muted" />
                <span className="font-medium text-sm">Passageiros</span>
              </div>
              <div className="flex items-center gap-3">
                <button
                  onClick={() => setPassengerCount(Math.max(1, passengerCount - 1))}
                  className="w-8 h-8 rounded-full bg-background flex items-center justify-center text-lg font-medium active:scale-95 transition-transform"
                  disabled={passengerCount <= 1}
                >
                  -
                </button>
                <span className="w-6 text-center font-semibold text-lg">{passengerCount}</span>
                <button
                  onClick={() => setPassengerCount(Math.min(10, passengerCount + 1))}
                  className="w-8 h-8 rounded-full bg-background flex items-center justify-center text-lg font-medium active:scale-95 transition-transform"
                  disabled={passengerCount >= 10}
                >
                  +
                </button>
              </div>
            </div>

            {/* Trip info row */}
            <div className="flex items-center justify-between mb-4">
              <div className="flex items-center gap-4">
                <div className="flex items-center gap-1.5 text-muted">
                  <Clock className="w-4 h-4" />
                  <span className="text-sm font-medium">{time} min</span>
                </div>
                <div className="flex items-center gap-1.5 text-muted">
                  <Navigation className="w-4 h-4" />
                  <span className="text-sm font-medium">{distance.toFixed(1)} km</span>
                </div>
              </div>
              
              <div className="text-right">
                <p className="text-xs text-muted">
                  {passengerCount > 1 ? `${passengerCount}x R$${pricePerPerson.toFixed(0)}` : 'total'}
                </p>
                <p className="text-2xl font-bold text-foreground">
                  R${totalPrice.toFixed(0)}
                </p>
              </div>
            </div>

            {/* Payment info */}
            <div className="bg-primary/10 rounded-lg p-3 mb-4">
              <p className="text-sm text-center text-primary font-medium">
                💳 Pagamento via PIX antes de confirmar
              </p>
            </div>

            {/* Confirm button */}
            <Button
              variant="default"
              size="lg"
              fullWidth
              onClick={handleConfirm}
              disabled={isCreating}
              className="h-14"
            >
              {isCreating ? 'Gerando pagamento...' : 'Pagar e Confirmar Viagem'}
            </Button>
          </div>
        </div>
      )}

      {/* Payment Modal */}
      <PaymentModal
        isOpen={showPaymentModal}
        onClose={handlePaymentCancel}
        onPaymentComplete={handlePaymentComplete}
        rideId={currentRideId || ''}
        amount={totalPrice}
        passengerDeviceId={user?.id || ''}
        passengerName={passengerProfile?.full_name || ''}
        passengerCpf={passengerProfile?.cpf || ''}
        passengerEmail={passengerProfile?.email || ''}
      />

      {/* Profile Incomplete Modal */}
      <ProfileIncompleteModal
        isOpen={showProfileModal}
        onClose={() => setShowProfileModal(false)}
        onGoToProfile={() => {
          setShowProfileModal(false);
          navigate('/passenger/profile');
        }}
        missingFields={missingFields}
        userType="passenger"
      />
    </div>
  );
};

export default RequestRide;
