import { useState, useEffect } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { AlertTriangle, Clock, Route, Phone, MessageCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import GoogleMapView from '@/components/GoogleMapView';
import { useApp } from '@/contexts/AppContext';
import { supabase } from '@/integrations/supabase/client';
import { DbRide } from '@/types';
import { toast } from 'sonner';
import { getCurrentRide } from '@/services/rideService';
import { useAuthContext } from '@/contexts/AuthContext';

const InRide = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { user } = useAuthContext();
  const { origin, destination, setOrigin, setDestination } = useApp();
  
  const [pilotPosition, setPilotPosition] = useState<{ lat: number; lng: number } | null>(null);
  const [currentRide, setCurrentRide] = useState<DbRide | null>(null);
  const [startTime, setStartTime] = useState<Date | null>(null);
  const [elapsedTime, setElapsedTime] = useState(0);

  const initialRideId = (location.state as any)?.rideId as string | undefined;
  const [rideId, setRideId] = useState<string | null>(initialRideId || null);

  // Ensure we always have a rideId (handles page refresh)
  useEffect(() => {
    if (!rideId && user?.id) {
      getCurrentRide(user.id).then((ride) => {
        if (ride && ride.status === 'in_progress') {
          setRideId(ride.id);
        }
      });
    }
  }, [rideId, user?.id]);

  // Fetch ride and subscribe to updates
  useEffect(() => {
    if (!rideId) return;

    const fetchRide = async () => {
      const { data, error } = await supabase
        .from('rides')
        .select('*')
        .eq('id', rideId)
        .single();

      if (data) {
        const ride = data as DbRide;
        setCurrentRide(ride);
        
        // Set origin/destination from ride data
        if (!origin && ride.origin_name) {
          setOrigin({
            id: 'origin',
            name: ride.origin_name,
            address: ride.origin_address || '',
            coordinates: [ride.origin_lng, ride.origin_lat],
          });
        }
        if (!destination && ride.destination_name) {
          setDestination({
            id: 'destination',
            name: ride.destination_name || '',
            address: ride.destination_address || '',
            coordinates: [ride.destination_lng || 0, ride.destination_lat || 0],
          });
        }
        
        // Set pilot position
        if (ride.pilot_lat && ride.pilot_lng) {
          setPilotPosition({ lat: ride.pilot_lat, lng: ride.pilot_lng });
        }
        
        // Set start time
        if (ride.started_at) {
          setStartTime(new Date(ride.started_at));
        } else {
          setStartTime(new Date());
        }
      }
    };

    fetchRide();

    // Polling fallback - check every 5 seconds
    const pollingInterval = setInterval(() => {
      console.log('[InRide] Polling for updates...');
      fetchRide();
    }, 5000);

    // Subscribe to real-time updates
    const channel = supabase
      .channel(`inride-${rideId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'rides',
          filter: `id=eq.${rideId}`,
        },
        (payload) => {
          console.log('[InRide] Ride update received:', payload);
          const updatedRide = payload.new as DbRide;
          setCurrentRide(updatedRide);
          
          // Update pilot position
          if (updatedRide.pilot_lat && updatedRide.pilot_lng) {
            setPilotPosition({ 
              lat: updatedRide.pilot_lat, 
              lng: updatedRide.pilot_lng 
            });
          }

          // Handle ride completion - when pilot finishes
          if (updatedRide.status === 'completed') {
            toast.success('Viagem concluída!');
            navigate('/passenger/completed', { state: { rideId } });
          }
          
          // Handle cancellation
          if (updatedRide.status === 'cancelled') {
            toast.error('Corrida cancelada');
            navigate('/passenger');
          }
        }
      )
      .subscribe((status) => {
        console.log('[InRide] Subscription status:', status);
      });

    return () => {
      clearInterval(pollingInterval);
      supabase.removeChannel(channel);
    };
  }, [rideId, navigate, origin, destination, setOrigin, setDestination]);

  // Timer for elapsed time
  useEffect(() => {
    if (!startTime) return;
    
    const interval = setInterval(() => {
      const now = new Date();
      const diff = Math.floor((now.getTime() - startTime.getTime()) / 1000);
      setElapsedTime(diff);
    }, 1000);

    return () => clearInterval(interval);
  }, [startTime]);

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60);
    const secs = seconds % 60;
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleCall = () => {
    if (currentRide?.pilot_phone) {
      window.open(`tel:${currentRide.pilot_phone}`);
    }
  };

  const handleWhatsApp = () => {
    if (currentRide?.pilot_phone) {
      window.open(`https://wa.me/${currentRide.pilot_phone.replace(/\D/g, '')}`);
    }
  };

  const price = currentRide ? Number(currentRide.price) : 0;

  return (
    <div className="h-screen h-[100dvh] bg-background relative overflow-hidden">
      {/* Map */}
      <div className="absolute inset-0">
        <GoogleMapView 
          showBoats={false}
          origin={origin}
          destination={destination}
          pilotPosition={pilotPosition}
          animateBoatOnRoute={true}
        />
      </div>

      {/* Status banner */}
      <div className="absolute top-4 left-4 right-4 z-30 safe-area-top">
        <div className="bg-secondary text-secondary-foreground rounded-xl px-4 py-3 flex items-center gap-3 shadow-lg">
          <span className="text-2xl">🚤</span>
          <div className="flex-1">
            <p className="font-bold text-sm">Em viagem</p>
            <p className="text-xs opacity-90">
              {currentRide?.pilot_name || 'Piloto'} está levando você ao destino
            </p>
          </div>
          <div className="text-right">
            <p className="text-lg font-bold">{formatTime(elapsedTime)}</p>
          </div>
        </div>
      </div>

      {/* Bottom card */}
      <div className="absolute bottom-0 left-0 right-0 z-30 bg-card rounded-t-2xl shadow-sheet p-4 animate-slide-up safe-area-bottom">
        {/* Destination info */}
        <div className="text-center mb-4">
          <p className="text-xs text-muted mb-0.5">Em viagem para</p>
          <p className="text-lg font-bold text-foreground">{destination?.name || currentRide?.destination_name}</p>
        </div>

        {/* Stats */}
        <div className="flex items-center justify-center gap-6 mb-4">
          <div className="flex items-center gap-1.5 bg-muted/10 px-3 py-2 rounded-lg">
            <Clock className="w-4 h-4 text-secondary" />
            <span className="text-base font-semibold text-foreground">
              {formatTime(elapsedTime)}
            </span>
          </div>
          <div className="flex items-center gap-1.5 bg-muted/10 px-3 py-2 rounded-lg">
            <span className="text-base font-semibold text-foreground">
              R$ {price.toFixed(2).replace('.', ',')}
            </span>
          </div>
        </div>

        {/* Pilot contact */}
        <div className="flex items-center justify-center gap-3 mb-4">
          <Button
            variant="outline"
            size="sm"
            onClick={handleCall}
            className="flex items-center gap-2"
          >
            <Phone className="w-4 h-4" />
            Ligar
          </Button>
          <Button
            variant="outline"
            size="sm"
            onClick={handleWhatsApp}
            className="flex items-center gap-2"
          >
            <MessageCircle className="w-4 h-4" />
            WhatsApp
          </Button>
        </div>

        {/* Info text */}
        <div className="bg-muted/10 rounded-lg p-3 mb-4">
          <p className="text-xs text-muted text-center">
            A viagem será finalizada pelo piloto quando vocês chegarem ao destino
          </p>
        </div>

        <Button
          variant="outline"
          fullWidth
          className="border-destructive text-destructive hover:bg-destructive/10 h-11"
        >
          <AlertTriangle className="w-4 h-4 mr-2" />
          Emergência
        </Button>
      </div>
    </div>
  );
};

export default InRide;
