import { supabase } from '@/integrations/supabase/client';
import { Location } from '@/types';

interface CreateRideParams {
  origin: Location;
  destination: Location;
  price: number;
  passengerCount: number;
  estimatedTime: number;
  userId: string;
}

export const createRide = async ({
  origin,
  destination,
  price,
  passengerCount,
  estimatedTime,
  userId,
}: CreateRideParams) => {
  const { data, error } = await supabase
    .from('rides')
    .insert({
      passenger_device_id: userId,
      passenger_user_id: userId,
      origin_name: origin.name,
      origin_address: origin.address,
      origin_lat: origin.coordinates[1],
      origin_lng: origin.coordinates[0],
      destination_name: destination.name,
      destination_address: destination.address,
      destination_lat: destination.coordinates[1],
      destination_lng: destination.coordinates[0],
      price: price * passengerCount,
      estimated_time: estimatedTime,
      status: 'pending',
    })
    .select()
    .single();

  if (error) {
    console.error('Error creating ride:', error);
    throw error;
  }

  return data;
};

export const cancelRide = async (rideId: string) => {
  const { error } = await supabase
    .from('rides')
    .update({ status: 'cancelled' })
    .eq('id', rideId);

  if (error) {
    console.error('Error cancelling ride:', error);
    throw error;
  }
};

// Get current ACTIVE ride for a user - only pending, accepted, pilot_arriving, in_progress
export const getCurrentRide = async (userId: string) => {
  console.log('[getCurrentRide] Searching for active ride, userId:', userId);

  const { data, error } = await supabase
    .from('rides')
    .select('*')
    .or(`passenger_user_id.eq.${userId},passenger_device_id.eq.${userId}`)
    .in('status', ['pending', 'accepted', 'pilot_arriving', 'in_progress'])
    .order('created_at', { ascending: false })
    .limit(1)
    .maybeSingle();

  if (error) {
    console.error('[getCurrentRide] Error fetching current ride:', error);
    throw error;
  }

  console.log('[getCurrentRide] Found active ride:', data?.id, 'status:', data?.status);
  return data;
};
