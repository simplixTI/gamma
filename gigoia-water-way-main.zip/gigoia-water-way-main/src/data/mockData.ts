import { Location, Pilot, Ride } from '@/types';

// Coordenadas reais da região da Ilha da Gigoia
export const locations: Location[] = [
  {
    id: '1',
    name: 'Pier Principal Gigoia',
    address: 'Entrada principal da ilha',
    coordinates: [-43.3545, -22.9965], // [lng, lat]
    estimatedTime: '~2 min',
  },
  {
    id: '2',
    name: 'Marina Barra Clube',
    address: 'Próximo ao clube',
    coordinates: [-43.3580, -23.0020],
    estimatedTime: '~4 min',
  },
  {
    id: '3',
    name: 'Pier Itanhangá',
    address: 'Ilha Itanhangá',
    coordinates: [-43.3510, -23.0005],
    estimatedTime: '~5 min',
  },
  {
    id: '4',
    name: 'OCYÁ Ilha',
    address: 'Restaurante OCYÁ',
    coordinates: [-43.3530, -22.9940],
    estimatedTime: '~3 min',
  },
  {
    id: '5',
    name: 'Pier Ilha Primeira',
    address: 'Ilha Primeira',
    coordinates: [-43.3480, -22.9980],
    estimatedTime: '~6 min',
  },
  {
    id: '6',
    name: 'Canal de Marapendi',
    address: 'Entrada pelo canal',
    coordinates: [-43.3620, -22.9920],
    estimatedTime: '~7 min',
  },
];

export const mockPilot: Pilot = {
  id: 'pilot-1',
  name: 'Carlos Silva',
  photo: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&h=200&fit=crop&crop=face',
  rating: 4.9,
  boat: 'Gamma Maritimo',
  phone: '+55 21 99999-9999',
};

export const mockPassenger = {
  id: 'passenger-1',
  name: 'Ana Santos',
  photo: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face',
};

// Mock rides for pilot dashboard (simplified without boatType)
export const mockRides: Ride[] = [
  {
    id: 'ride-1',
    passengerId: 'passenger-1',
    passengerName: 'Ana Santos',
    passengerPhoto: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&h=200&fit=crop&crop=face',
    origin: locations[0],
    destination: locations[2],
    status: 'pending',
    price: 5,
    estimatedTime: 8,
    distance: 1.2,
    createdAt: new Date(),
  },
  {
    id: 'ride-2',
    passengerId: 'passenger-2',
    passengerName: 'Pedro Lima',
    passengerPhoto: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&h=200&fit=crop&crop=face',
    origin: locations[1],
    destination: locations[4],
    status: 'pending',
    price: 7,
    estimatedTime: 12,
    distance: 1.8,
    createdAt: new Date(Date.now() - 60000), // 1 min ago
  },
  {
    id: 'ride-3',
    passengerId: 'passenger-3',
    passengerName: 'Maria Costa',
    passengerPhoto: 'https://images.unsplash.com/photo-1438761681033-6461ffad8d80?w=200&h=200&fit=crop&crop=face',
    origin: locations[3],
    destination: locations[5],
    status: 'pending',
    price: 8,
    estimatedTime: 15,
    distance: 2.1,
    createdAt: new Date(Date.now() - 120000), // 2 min ago
  },
];