import { useState, useEffect, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface PilotStats {
  ridesToday: number;
  earnings: number;
  tips: number;
  rating: number;
  totalRides: number;
}

// Get or create pilot from database based on device fingerprint
const getDeviceFingerprint = (): string => {
  // Create a simple fingerprint based on browser characteristics
  const nav = navigator;
  const screen = window.screen;
  const fingerprint = [
    nav.userAgent,
    nav.language,
    screen.width,
    screen.height,
    screen.colorDepth,
    new Date().getTimezoneOffset(),
  ].join('|');
  
  // Create a hash of the fingerprint
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return `pilot_${Math.abs(hash).toString(36)}`;
};

export const usePilotStats = () => {
  const [stats, setStats] = useState<PilotStats>({
    ridesToday: 0,
    earnings: 0,
    tips: 0,
    rating: 0,
    totalRides: 0,
  });
  const [loading, setLoading] = useState(true);
  const [pilotId, setPilotId] = useState<string | null>(null);
  const deviceFingerprint = getDeviceFingerprint();

  // Get or create pilot in database
  const getOrCreatePilot = useCallback(async () => {
    try {
      // First, try to find existing pilot by device_id
      const { data: existingPilot, error: findError } = await supabase
        .from('pilots')
        .select('id')
        .eq('device_id', deviceFingerprint)
        .maybeSingle();

      if (findError) {
        console.error('Error finding pilot:', findError);
        return null;
      }

      if (existingPilot) {
        return existingPilot.id;
      }

      // Create new pilot if not found
      const { data: newPilot, error: createError } = await supabase
        .from('pilots')
        .insert({
          device_id: deviceFingerprint,
          name: 'Novo Piloto',
        })
        .select('id')
        .single();

      if (createError) {
        console.error('Error creating pilot:', createError);
        return null;
      }

      return newPilot.id;
    } catch (error) {
      console.error('Error in getOrCreatePilot:', error);
      return null;
    }
  }, [deviceFingerprint]);

  const fetchStats = useCallback(async (currentPilotId: string) => {
    try {
      // Get today's date at midnight
      const today = new Date();
      today.setHours(0, 0, 0, 0);

      // Fetch all completed rides for this pilot
      const { data: allRides, error: allError } = await supabase
        .from('rides')
        .select('id, price, tip, rating, completed_at, created_at')
        .eq('pilot_id', currentPilotId)
        .eq('status', 'completed');

      if (allError) {
        console.error('Error fetching all rides:', allError);
        return;
      }

      // Fetch today's completed rides
      const { data: todayRides, error: todayError } = await supabase
        .from('rides')
        .select('id, price, tip, rating')
        .eq('pilot_id', currentPilotId)
        .eq('status', 'completed')
        .gte('completed_at', today.toISOString());

      if (todayError) {
        console.error('Error fetching today rides:', todayError);
        return;
      }

      // Calculate stats
      const ridesToday = todayRides?.length || 0;
      const totalRides = allRides?.length || 0;

      const todayEarnings = todayRides?.reduce((sum, ride) => sum + Number(ride.price || 0), 0) || 0;
      const todayTips = todayRides?.reduce((sum, ride) => sum + Number(ride.tip || 0), 0) || 0;

      // Calculate average rating from all rated rides
      const ratedRides = allRides?.filter(r => r.rating !== null && r.rating > 0) || [];
      const avgRating = ratedRides.length > 0 
        ? ratedRides.reduce((sum, r) => sum + (r.rating || 0), 0) / ratedRides.length
        : 5.0; // Default to 5 for new pilots

      setStats({
        ridesToday,
        earnings: todayEarnings + todayTips,
        tips: todayTips,
        rating: Math.round(avgRating * 10) / 10, // Round to 1 decimal
        totalRides,
      });
    } catch (error) {
      console.error('Error in fetchStats:', error);
    } finally {
      setLoading(false);
    }
  }, []);

  // Initialize pilot and fetch stats
  useEffect(() => {
    const init = async () => {
      const id = await getOrCreatePilot();
      if (id) {
        setPilotId(id);
        await fetchStats(id);
      } else {
        setLoading(false);
      }
    };
    init();
  }, [getOrCreatePilot, fetchStats]);

  // Subscribe to ride changes
  useEffect(() => {
    if (!pilotId) return;

    const channel = supabase
      .channel('pilot-stats')
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'rides',
          filter: `pilot_id=eq.${pilotId}`,
        },
        () => {
          // Refetch stats when any ride for this pilot changes
          fetchStats(pilotId);
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(channel);
    };
  }, [pilotId, fetchStats]);

  return { stats, loading, pilotId, refetch: () => pilotId && fetchStats(pilotId) };
};

// Export for use in other components
export const getPilotIdFromDevice = async (): Promise<string | null> => {
  const nav = navigator;
  const screen = window.screen;
  const fingerprint = [
    nav.userAgent,
    nav.language,
    screen.width,
    screen.height,
    screen.colorDepth,
    new Date().getTimezoneOffset(),
  ].join('|');
  
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  const deviceFingerprint = `pilot_${Math.abs(hash).toString(36)}`;

  const { data, error } = await supabase
    .from('pilots')
    .select('id')
    .eq('device_id', deviceFingerprint)
    .maybeSingle();

  if (error || !data) {
    return null;
  }

  return data.id;
};
