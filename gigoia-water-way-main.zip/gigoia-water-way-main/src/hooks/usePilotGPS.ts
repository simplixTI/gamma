import { useEffect, useRef, useCallback } from 'react';
import { supabase } from '@/integrations/supabase/client';

interface UsePilotGPSOptions {
  rideId: string | undefined;
  isActive: boolean;
  intervalMs?: number;
}

export const usePilotGPS = ({ rideId, isActive, intervalMs = 5000 }: UsePilotGPSOptions) => {
  const watchIdRef = useRef<number | null>(null);
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const updatePilotPosition = useCallback(async (lat: number, lng: number) => {
    if (!rideId) return;

    const { error } = await supabase
      .from('rides')
      .update({
        pilot_lat: lat,
        pilot_lng: lng,
        updated_at: new Date().toISOString(),
      })
      .eq('id', rideId);

    if (error) {
      console.error('Error updating pilot position:', error);
    }
  }, [rideId]);

  const getCurrentPosition = useCallback(() => {
    if (!navigator.geolocation) {
      console.error('Geolocation not supported');
      return;
    }

    navigator.geolocation.getCurrentPosition(
      (position) => {
        const { latitude, longitude } = position.coords;
        updatePilotPosition(latitude, longitude);
      },
      (error) => {
        console.error('Error getting position:', error);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0,
      }
    );
  }, [updatePilotPosition]);

  useEffect(() => {
    if (!isActive || !rideId) {
      // Clear interval when not active
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      return;
    }

    // Get initial position
    getCurrentPosition();

    // Set up interval for position updates
    intervalRef.current = setInterval(() => {
      getCurrentPosition();
    }, intervalMs);

    return () => {
      if (intervalRef.current) {
        clearInterval(intervalRef.current);
        intervalRef.current = null;
      }
      if (watchIdRef.current !== null) {
        navigator.geolocation.clearWatch(watchIdRef.current);
        watchIdRef.current = null;
      }
    };
  }, [isActive, rideId, intervalMs, getCurrentPosition]);

  return { updatePilotPosition, getCurrentPosition };
};
