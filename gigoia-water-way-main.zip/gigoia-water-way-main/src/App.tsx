import { Toaster } from "@/components/ui/toaster";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import { AppProvider } from "@/contexts/AppContext";
import { AuthProvider } from "@/contexts/AuthContext";
import { SettingsInitializer } from "@/components/SettingsInitializer";
import ProtectedRoute from "@/components/ProtectedRoute";
import ConnectionStatusBanner from "@/components/ConnectionStatusBanner";
import Landing from "./pages/Landing";
import PassengerAuth from "./pages/auth/PassengerAuth";
import PilotAuth from "./pages/auth/PilotAuth";
import PassengerHome from "./pages/passenger/PassengerHome";
import RequestRide from "./pages/passenger/RequestRide";
import SearchingPilot from "./pages/passenger/SearchingPilot";
import Tracking from "./pages/passenger/Tracking";
import InRide from "./pages/passenger/InRide";
import Completed from "./pages/passenger/Completed";
import RideHistory from "./pages/passenger/RideHistory";
import Profile from "./pages/passenger/Profile";
import Payment from "./pages/passenger/Payment";
import Favorites from "./pages/passenger/Favorites";
import Settings from "./pages/passenger/Settings";
import PilotDashboard from "./pages/pilot/PilotDashboard";
import ActiveRide from "./pages/pilot/ActiveRide";
import PilotHistory from "./pages/pilot/PilotHistory";
import PilotProfile from "./pages/pilot/PilotProfile";
import PilotProfileEdit from "./pages/pilot/PilotProfileEdit";
import Earnings from "./pages/pilot/Earnings";
import PilotSettings from "./pages/pilot/PilotSettings";
import NotFound from "./pages/NotFound";

const queryClient = new QueryClient();

const App = () => (
  <QueryClientProvider client={queryClient}>
    <AuthProvider>
      <SettingsInitializer>
        <AppProvider>
          <TooltipProvider>
            <ConnectionStatusBanner />
            <Toaster />
            <Sonner />
            <BrowserRouter>
              <Routes>
                <Route path="/" element={<Landing />} />
                
                {/* Auth routes */}
                <Route path="/auth/passenger" element={<PassengerAuth />} />
                <Route path="/auth/pilot" element={<PilotAuth />} />
                
                {/* Passenger routes */}
                <Route path="/passenger" element={
                  <ProtectedRoute requiredRole="passenger">
                    <PassengerHome />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/request" element={
                  <ProtectedRoute requiredRole="passenger">
                    <RequestRide />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/searching" element={
                  <ProtectedRoute requiredRole="passenger">
                    <SearchingPilot />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/tracking" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Tracking />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/in-ride" element={
                  <ProtectedRoute requiredRole="passenger">
                    <InRide />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/completed" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Completed />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/history" element={
                  <ProtectedRoute requiredRole="passenger">
                    <RideHistory />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/profile" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Profile />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/payment" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Payment />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/favorites" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Favorites />
                  </ProtectedRoute>
                } />
                <Route path="/passenger/settings" element={
                  <ProtectedRoute requiredRole="passenger">
                    <Settings />
                  </ProtectedRoute>
                } />
                
                {/* Pilot routes */}
                <Route path="/pilot" element={
                  <ProtectedRoute requiredRole="pilot">
                    <PilotDashboard />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/ride/:rideId" element={
                  <ProtectedRoute requiredRole="pilot">
                    <ActiveRide />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/history" element={
                  <ProtectedRoute requiredRole="pilot">
                    <PilotHistory />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/profile" element={
                  <ProtectedRoute requiredRole="pilot">
                    <PilotProfile />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/profile/edit" element={
                  <ProtectedRoute requiredRole="pilot">
                    <PilotProfileEdit />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/earnings" element={
                  <ProtectedRoute requiredRole="pilot">
                    <Earnings />
                  </ProtectedRoute>
                } />
                <Route path="/pilot/settings" element={
                  <ProtectedRoute requiredRole="pilot">
                    <PilotSettings />
                  </ProtectedRoute>
                } />
                
                <Route path="*" element={<NotFound />} />
              </Routes>
            </BrowserRouter>
          </TooltipProvider>
        </AppProvider>
      </SettingsInitializer>
    </AuthProvider>
  </QueryClientProvider>
);

export default App;
