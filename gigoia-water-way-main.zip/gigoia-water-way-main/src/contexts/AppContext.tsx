import React, { createContext, useContext, useState, ReactNode } from 'react';
import { UserRole, RideStatus, Location, Pilot } from '@/types';
import { locations, mockPilot } from '@/data/mockData';

interface AppContextType {
  userRole: UserRole | null;
  setUserRole: (role: UserRole | null) => void;
  rideStatus: RideStatus;
  setRideStatus: (status: RideStatus) => void;
  origin: Location | null;
  setOrigin: (location: Location | null) => void;
  destination: Location | null;
  setDestination: (location: Location | null) => void;
  currentPilot: Pilot | null;
  setCurrentPilot: (pilot: Pilot | null) => void;
  isPilotOnline: boolean;
  setIsPilotOnline: (online: boolean) => void;
  passengerCount: number;
  setPassengerCount: (count: number) => void;
  calculatePrice: () => number;
  calculateDistance: () => number;
  calculateTime: () => number;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [userRole, setUserRole] = useState<UserRole | null>(null);
  const [rideStatus, setRideStatus] = useState<RideStatus>('idle');
  const [origin, setOrigin] = useState<Location | null>(null);
  const [destination, setDestination] = useState<Location | null>(null);
  const [currentPilot, setCurrentPilot] = useState<Pilot | null>(null);
  const [isPilotOnline, setIsPilotOnline] = useState(false);
  const [passengerCount, setPassengerCount] = useState(1);

  const calculateDistance = () => {
    if (!origin || !destination) return 0;
    // Simple distance calculation (mock)
    const dx = origin.coordinates[0] - destination.coordinates[0];
    const dy = origin.coordinates[1] - destination.coordinates[1];
    return Math.round(Math.sqrt(dx * dx + dy * dy) * 100 * 10) / 10;
  };

  const calculateTime = () => {
    const distance = calculateDistance();
    return Math.round(distance * 5 + 3); // ~5 min per km + 3 min base
  };

  const calculatePrice = () => {
    const distance = calculateDistance();
    // Preço varia de R$3 (perto) a R$10 (longe)
    // Distância máxima considerada: ~1.5km
    const minPrice = 3;
    const maxPrice = 10;
    const maxDistance = 1.5; // km
    
    const normalizedDistance = Math.min(distance, maxDistance) / maxDistance;
    const price = minPrice + (normalizedDistance * (maxPrice - minPrice));
    
    return Math.round(price * 100) / 100;
  };

  return (
    <AppContext.Provider
      value={{
        userRole,
        setUserRole,
        rideStatus,
        setRideStatus,
        origin,
        setOrigin,
        destination,
        setDestination,
        currentPilot,
        setCurrentPilot,
        isPilotOnline,
        setIsPilotOnline,
        passengerCount,
        setPassengerCount,
        calculatePrice,
        calculateDistance,
        calculateTime,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
