import { ReactNode } from 'react';
import { cn } from '@/lib/utils';

interface BottomSheetProps {
  children: ReactNode;
  className?: string;
  expanded?: boolean;
}

const BottomSheet: React.FC<BottomSheetProps> = ({
  children,
  className,
  expanded = false,
}) => {
  return (
    <div
      className={cn(
        "fixed bottom-0 left-0 right-0 bg-card rounded-t-2xl shadow-sheet z-40",
        "transition-all duration-300 ease-out",
        expanded ? "max-h-[80vh]" : "max-h-[45vh]",
        className
      )}
    >
      <div className="flex justify-center py-2">
        <div className="w-10 h-1 bg-border rounded-full" />
      </div>
      <div className="px-4 pb-6 overflow-y-auto max-h-[calc(100%-32px)] overscroll-contain">
        {children}
      </div>
    </div>
  );
};

export default BottomSheet;
