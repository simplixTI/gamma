import { useCallback, useState, useEffect } from 'react';
import { GoogleMap, useJsApiLoader, Marker, InfoWindow, Polyline } from '@react-google-maps/api';
import { Navigation, AlertCircle } from 'lucide-react';
import { cn } from '@/lib/utils';
import { Location } from '@/types';
import { locations } from '@/data/mockData';
import { Button } from '@/components/ui/button';

interface GoogleMapViewProps {
  className?: string;
  showBoats?: boolean;
  onLocationSelect?: (location: Location) => void;
  selectedLocation?: Location | null;
  showRoute?: boolean;
  origin?: Location | null;
  destination?: Location | null;
  pilotPosition?: { lat: number; lng: number } | null;
  animateBoatOnRoute?: boolean;
}

// Ilha da Gigoia center coordinates - área Ilha Primeira / Ilha da Jibola
const GIGOIA_CENTER = {
  lat: -22.9875,
  lng: -43.3500,
};

const mapContainerStyle = {
  width: '100%',
  height: '100%',
};

const mapOptions: google.maps.MapOptions = {
  disableDefaultUI: true,
  zoomControl: false,
  mapTypeControl: false,
  streetViewControl: false,
  fullscreenControl: false,
  gestureHandling: 'greedy',
  styles: [
    {
      featureType: 'water',
      elementType: 'geometry',
      stylers: [{ color: '#a8dcd9' }],
    },
    {
      featureType: 'landscape',
      elementType: 'geometry',
      stylers: [{ color: '#f0f0f0' }],
    },
    {
      featureType: 'poi',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'transit',
      stylers: [{ visibility: 'off' }],
    },
    {
      featureType: 'road',
      elementType: 'geometry',
      stylers: [{ color: '#ffffff' }],
    },
    {
      featureType: 'road',
      elementType: 'labels',
      stylers: [{ visibility: 'simplified' }],
    },
  ],
};

// Boat positions na região da Gigoia
const boatPositions = [
  { id: 1, lat: -22.9960, lng: -43.3530 },
  { id: 2, lat: -22.9985, lng: -43.3560 },
  { id: 3, lat: -22.9950, lng: -43.3510 },
];

const GoogleMapView: React.FC<GoogleMapViewProps> = ({
  className,
  showBoats = true,
  onLocationSelect,
  selectedLocation,
  showRoute = false,
  origin,
  destination,
  pilotPosition,
  animateBoatOnRoute = false,
}) => {
  const GOOGLE_MAPS_API_KEY = 'AIzaSyDcgpO1JqG6-5yFTwNkgpQH3Yb0ztGCjUM';
  const [apiKey] = useState<string>(GOOGLE_MAPS_API_KEY);
  const [selectedMarker, setSelectedMarker] = useState<Location | null>(null);
  const [map, setMap] = useState<google.maps.Map | null>(null);
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);

  const { isLoaded, loadError } = useJsApiLoader({
    googleMapsApiKey: apiKey,
    id: 'google-map-script',
  });

  // Get user's location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        () => {
          setUserLocation(GIGOIA_CENTER);
        }
      );
    } else {
      setUserLocation(GIGOIA_CENTER);
    }
  }, []);

  const onLoad = useCallback((map: google.maps.Map) => {
    setMap(map);
  }, []);

  const onUnmount = useCallback(() => {
    setMap(null);
  }, []);

  const handleMarkerClick = (location: Location) => {
    setSelectedMarker(location);
    if (onLocationSelect) {
      onLocationSelect(location);
    }
  };

  if (loadError) {
    return (
      <div className={cn("relative w-full h-full bg-destructive/5 flex items-center justify-center p-4", className)}>
        <div className="bg-card rounded-2xl shadow-elevated p-4 max-w-sm w-full text-center">
          <AlertCircle className="w-10 h-10 text-destructive mx-auto mb-3" />
          <h3 className="font-bold text-foreground mb-2 text-sm">Erro ao carregar o mapa</h3>
          <p className="text-xs text-muted mb-3">
            Verifique sua conexão com a internet.
          </p>
          <Button
            variant="outline"
            size="sm"
            onClick={() => window.location.reload()}
          >
            Tentar novamente
          </Button>
        </div>
      </div>
    );
  }

  if (!isLoaded) {
    return (
      <div className={cn("relative w-full h-full bg-secondary/5 flex items-center justify-center", className)}>
        <div className="flex flex-col items-center gap-3">
          <div className="w-10 h-10 border-3 border-secondary border-t-transparent rounded-full animate-spin" />
          <p className="text-muted text-sm">Carregando mapa...</p>
        </div>
      </div>
    );
  }

  return (
    <div className={cn("relative w-full h-full touch-pan-x touch-pan-y", className)}>
      <GoogleMap
        mapContainerStyle={mapContainerStyle}
        center={GIGOIA_CENTER}
        zoom={16}
        onLoad={onLoad}
        onUnmount={onUnmount}
        options={mapOptions}
      >
        {/* User location marker */}
        {userLocation && (
          <Marker
            position={userLocation}
            icon={{
              path: google.maps.SymbolPath.CIRCLE,
              scale: 8,
              fillColor: '#00A8E8',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 2,
            }}
            zIndex={10}
          />
        )}

        {/* Pier/Location markers */}
        {locations.map((location) => (
          <Marker
            key={location.id}
            position={{
              lat: location.coordinates[1],
              lng: location.coordinates[0],
            }}
            onClick={() => handleMarkerClick(location)}
            icon={{
              path: 'M12 2C8.13 2 5 5.13 5 9c0 5.25 7 13 7 13s7-7.75 7-13c0-3.87-3.13-7-7-7zm0 9.5c-1.38 0-2.5-1.12-2.5-2.5s1.12-2.5 2.5-2.5 2.5 1.12 2.5 2.5-1.12 2.5-2.5 2.5z',
              fillColor: selectedLocation?.id === location.id ? '#00A8E8' : '#10B981',
              fillOpacity: 1,
              strokeColor: '#ffffff',
              strokeWeight: 2,
              scale: 1.3,
              anchor: new google.maps.Point(12, 22),
            }}
          />
        ))}

        {/* Boat markers */}
        {showBoats && boatPositions.map((boat) => (
          <Marker
            key={boat.id}
            position={{ lat: boat.lat, lng: boat.lng }}
            icon={{
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg xmlns="http://www.w3.org/2000/svg" width="36" height="36" viewBox="0 0 36 36">
                  <circle cx="18" cy="18" r="16" fill="white" stroke="#00A8E8" stroke-width="2"/>
                  <text x="18" y="24" text-anchor="middle" font-size="18">🚤</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(36, 36),
            }}
            zIndex={5}
          />
        ))}

        {/* Route line from pilot to origin (blue) with animated icon */}
        {pilotPosition && origin && (
          <Polyline
            path={[
              pilotPosition,
              { lat: origin.coordinates[1], lng: origin.coordinates[0] }
            ]}
            options={{
              strokeColor: '#00A8E8',
              strokeOpacity: 0.8,
              strokeWeight: 4,
              geodesic: true,
              icons: animateBoatOnRoute ? [
                {
                  icon: {
                    path: 'M 0,-1 0,1',
                    strokeOpacity: 1,
                    scale: 3,
                    strokeColor: '#00A8E8',
                  },
                  offset: '0',
                  repeat: '15px',
                },
                {
                  icon: {
                    path: google.maps.SymbolPath.CIRCLE,
                    scale: 6,
                    strokeColor: '#00A8E8',
                    fillColor: '#ffffff',
                    fillOpacity: 1,
                    strokeWeight: 2,
                  },
                  offset: '0%',
                }
              ] : [{
                icon: {
                  path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                  scale: 3,
                  strokeColor: '#00A8E8',
                  fillColor: '#00A8E8',
                  fillOpacity: 1,
                },
                offset: '50%',
              }],
            }}
          />
        )}

        {/* Route line from origin to destination (green) */}
        {origin && destination && (
          <Polyline
            path={[
              { lat: origin.coordinates[1], lng: origin.coordinates[0] },
              { lat: destination.coordinates[1], lng: destination.coordinates[0] }
            ]}
            options={{
              strokeColor: '#22c55e',
              strokeOpacity: 0.7,
              strokeWeight: 3,
              geodesic: true,
              icons: [{
                icon: {
                  path: google.maps.SymbolPath.FORWARD_CLOSED_ARROW,
                  scale: 3,
                  strokeColor: '#22c55e',
                  fillColor: '#22c55e',
                  fillOpacity: 1,
                },
                offset: '50%',
              }],
            }}
          />
        )}

        {/* Pilot position marker */}
        {pilotPosition && (
          <Marker
            position={pilotPosition}
            icon={{
              url: 'data:image/svg+xml;charset=UTF-8,' + encodeURIComponent(`
                <svg xmlns="http://www.w3.org/2000/svg" width="44" height="44" viewBox="0 0 44 44">
                  <circle cx="22" cy="22" r="20" fill="#00A8E8" stroke="white" stroke-width="2"/>
                  <text x="22" y="28" text-anchor="middle" font-size="20">🚤</text>
                </svg>
              `),
              scaledSize: new google.maps.Size(44, 44),
            }}
            zIndex={15}
          />
        )}

        {/* Info Window for selected marker */}
        {selectedMarker && (
          <InfoWindow
            position={{
              lat: selectedMarker.coordinates[1],
              lng: selectedMarker.coordinates[0],
            }}
            onCloseClick={() => setSelectedMarker(null)}
          >
            <div className="p-1.5 min-w-[120px]">
              <h3 className="font-bold text-gray-900 text-sm mb-0.5">{selectedMarker.name}</h3>
              <p className="text-xs text-gray-600 mb-1">{selectedMarker.address}</p>
              <p className="text-xs text-cyan-600 font-medium">{selectedMarker.estimatedTime}</p>
            </div>
          </InfoWindow>
        )}
      </GoogleMap>

      {/* Center on user button - mobile optimized */}
      {userLocation && (
        <button
          onClick={() => {
            if (map) {
              map.panTo(userLocation);
              map.setZoom(16);
            }
          }}
          className="absolute bottom-20 right-3 w-11 h-11 bg-card rounded-full shadow-elevated flex items-center justify-center active:scale-95 transition-transform z-10"
        >
          <Navigation className="w-5 h-5 text-secondary" />
        </button>
      )}
    </div>
  );
};

export default GoogleMapView;
