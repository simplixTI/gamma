import { useState, useEffect } from 'react';
import { X, Copy, Check, Clock, QrCode } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { supabase } from '@/integrations/supabase/client';
import { toast } from 'sonner';

interface PaymentModalProps {
  isOpen: boolean;
  onClose: () => void;
  rideId: string;
  amount: number;
  tip?: number;
  passengerDeviceId: string;
  pilotId?: string;
  passengerName?: string;
  passengerCpf?: string;
  passengerEmail?: string;
  onPaymentComplete?: () => void;
}

const PaymentModal: React.FC<PaymentModalProps> = ({
  isOpen,
  onClose,
  rideId,
  amount,
  tip = 0,
  passengerDeviceId,
  pilotId,
  passengerName,
  passengerCpf,
  passengerEmail,
  onPaymentComplete,
}) => {
  const [loading, setLoading] = useState(true);
  const [paymentData, setPaymentData] = useState<{
    qrCode: string;
    copyPaste: string;
    transactionId: string;
  } | null>(null);
  const [copied, setCopied] = useState(false);
  const [checkingPayment, setCheckingPayment] = useState(false);

  useEffect(() => {
    if (isOpen && rideId) {
      createPayment();
    }
  }, [isOpen, rideId]);

  const createPayment = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('create-pix-payment', {
        body: {
          rideId,
          amount,
          tip,
          passengerDeviceId,
          pilotId,
          passengerName,
          passengerCpf,
          passengerEmail,
        },
      });

      if (error) throw error;

      if (data.success) {
        setPaymentData(data.payment);
      } else {
        throw new Error(data.error || 'Erro ao criar pagamento');
      }
    } catch (error) {
      console.error('Error creating payment:', error);
      toast.error('Erro ao gerar pagamento PIX');
    } finally {
      setLoading(false);
    }
  };

  const handleCopy = async () => {
    if (paymentData?.copyPaste) {
      await navigator.clipboard.writeText(paymentData.copyPaste);
      setCopied(true);
      toast.success('Código PIX copiado!');
      setTimeout(() => setCopied(false), 3000);
    }
  };

  const handleConfirmPayment = async () => {
    setCheckingPayment(true);
    try {
      const { error } = await supabase
        .from('payments')
        .update({
          status: 'completed',
          paid_at: new Date().toISOString(),
        })
        .eq('ride_id', rideId)
        .eq('status', 'pending');

      if (error) throw error;

      toast.success('Pagamento confirmado!');
      onPaymentComplete?.();
      onClose();
    } catch (error) {
      console.error('Error confirming payment:', error);
      toast.error('Erro ao confirmar pagamento');
    } finally {
      setCheckingPayment(false);
    }
  };

  if (!isOpen) return null;

  const totalAmount = amount + tip;

  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/50 backdrop-blur-sm">
      <div className="w-full max-w-lg bg-card rounded-t-3xl shadow-2xl animate-slide-up safe-area-bottom">
        <div className="flex items-center justify-between p-4 border-b border-border">
          <h2 className="text-lg font-bold text-foreground">Pagamento PIX</h2>
          <Button variant="ghost" size="icon" onClick={onClose}>
            <X className="w-5 h-5" />
          </Button>
        </div>

        <div className="p-6">
          {loading ? (
            <div className="flex flex-col items-center py-12">
              <div className="w-12 h-12 border-3 border-primary border-t-transparent rounded-full animate-spin mb-4" />
              <p className="text-muted">Gerando QR Code PIX...</p>
            </div>
          ) : paymentData ? (
            <>
              <div className="text-center mb-6">
                <p className="text-sm text-muted mb-1">Valor total</p>
                <p className="text-4xl font-bold text-foreground">
                  R$ {totalAmount.toFixed(2)}
                </p>
              </div>

              <div className="bg-white rounded-2xl p-6 mb-4 flex flex-col items-center">
                <div className="w-48 h-48 bg-muted rounded-xl flex items-center justify-center mb-4">
                  <QrCode className="w-32 h-32 text-foreground" />
                </div>
                <p className="text-xs text-muted text-center">
                  Escaneie o QR Code com o app do seu banco
                </p>
              </div>

              <div className="bg-muted/30 rounded-xl p-4 mb-6">
                <p className="text-xs text-muted mb-2">Ou copie o código PIX:</p>
                <div className="flex gap-2">
                  <div className="flex-1 bg-background rounded-lg px-3 py-2 text-sm font-mono text-foreground truncate">
                    {paymentData.copyPaste.substring(0, 30)}...
                  </div>
                  <Button variant="outline" size="sm" onClick={handleCopy} className="shrink-0">
                    {copied ? <Check className="w-4 h-4 text-success" /> : <Copy className="w-4 h-4" />}
                  </Button>
                </div>
              </div>

              <div className="flex items-center justify-center gap-2 text-muted text-sm mb-6">
                <Clock className="w-4 h-4" />
                <span>Expira em 30 minutos</span>
              </div>

              <div className="space-y-3">
                <Button fullWidth size="lg" onClick={handleConfirmPayment} disabled={checkingPayment} className="h-14">
                  {checkingPayment ? 'Verificando...' : 'Já realizei o pagamento'}
                </Button>
                <Button variant="ghost" fullWidth onClick={onClose}>
                  Tentar novamente
                </Button>
              </div>
            </>
          ) : (
            <div className="text-center py-12">
              <p className="text-destructive mb-4">Erro ao gerar pagamento</p>
              <Button variant="outline" onClick={createPayment}>Tentar novamente</Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default PaymentModal;
