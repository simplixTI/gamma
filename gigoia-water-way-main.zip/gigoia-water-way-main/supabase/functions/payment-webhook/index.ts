import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!
    const supabase = createClient(supabaseUrl, supabaseServiceKey)

    const body = await req.json()
    console.log('Webhook received:', JSON.stringify(body))

    // BlackCat Pagamentos webhook payload structure
    // Supports multiple field names for flexibility
    const transactionId = body.transaction_id || body.transactionId || body.id || body.externalRef
    const status = body.status
    const event = body.event || body.type

    if (!transactionId) {
      console.error('Missing transaction identifier in webhook payload')
      return new Response(
        JSON.stringify({ error: 'Missing transaction identifier' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check if payment status is confirmed/paid - support multiple status values
    const paidStatuses = ['paid', 'confirmed', 'approved', 'completed', 'success']
    const paidEvents = ['payment.confirmed', 'payment.paid', 'payment.approved', 'pix.confirmed', 'pix.paid']
    
    const isPaid = paidStatuses.includes(status?.toLowerCase()) || 
                   paidEvents.includes(event?.toLowerCase())

    console.log(`Processing webhook - Transaction: ${transactionId}, Status: ${status}, Event: ${event}, IsPaid: ${isPaid}`)

    if (isPaid) {
      console.log(`Payment confirmed for transaction: ${transactionId}`)

      // Try to find payment by transaction_id first
      let { data: payment, error: findError } = await supabase
        .from('payments')
        .select('id, ride_id')
        .eq('transaction_id', transactionId)
        .maybeSingle()

      // If not found, try by ride_id (externalRef might be the ride_id)
      if (!payment) {
        const { data: paymentByRide } = await supabase
          .from('payments')
          .select('id, ride_id')
          .eq('ride_id', transactionId)
          .maybeSingle()
        payment = paymentByRide
      }

      if (!payment) {
        console.error(`Payment not found for transaction: ${transactionId}`)
        return new Response(
          JSON.stringify({ error: 'Payment not found' }),
          { status: 404, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Update payment status
      const { error: updateError } = await supabase
        .from('payments')
        .update({ 
          status: 'completed',
          paid_at: new Date().toISOString()
        })
        .eq('id', payment.id)

      if (updateError) {
        console.error('Error updating payment:', updateError)
        return new Response(
          JSON.stringify({ error: 'Failed to update payment' }),
          { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        )
      }

      // Also update ride payment_status
      if (payment.ride_id) {
        const { error: rideError } = await supabase
          .from('rides')
          .update({ payment_status: 'paid' })
          .eq('id', payment.ride_id)

        if (rideError) {
          console.error('Error updating ride payment status:', rideError)
        } else {
          console.log(`Ride ${payment.ride_id} payment status updated to paid`)
        }
      }

      console.log(`Payment ${payment.id} completed successfully`)

      return new Response(
        JSON.stringify({ success: true, message: 'Payment confirmed', paymentId: payment.id }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Handle failed/cancelled payments
    const failedStatuses = ['failed', 'cancelled', 'expired', 'rejected', 'refunded']
    const failedEvents = ['payment.failed', 'payment.cancelled', 'payment.expired', 'pix.expired']
    
    const isFailed = failedStatuses.includes(status?.toLowerCase()) || 
                     failedEvents.includes(event?.toLowerCase())

    if (isFailed) {
      console.log(`Payment failed/cancelled for transaction: ${transactionId}`)

      const { error } = await supabase
        .from('payments')
        .update({ status: 'failed' })
        .eq('transaction_id', transactionId)

      if (error) {
        console.error('Error updating failed payment:', error)
      }

      return new Response(
        JSON.stringify({ success: true, message: 'Payment failure recorded' }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // For other events, just acknowledge receipt
    console.log(`Webhook event received but not processed: ${event || status}`)
    return new Response(
      JSON.stringify({ success: true, message: 'Webhook received' }),
      { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error: unknown) {
    console.error('Webhook error:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})
